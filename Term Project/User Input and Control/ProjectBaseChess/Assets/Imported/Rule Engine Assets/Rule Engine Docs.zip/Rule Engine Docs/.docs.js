if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(searchString, position){
      position = position || 0;
      return this.substr(position, searchString.length) === searchString;
  };
}

function GetPageNameAndSection(str) {
	var last_ = str.lastIndexOf('_');
	if (last_ > 0) {
		return {
			page : str.substr(0, last_),
			section : str.substr(last_ + 1)
		};
	} else {
		return null;
	}
}

(function ($) {
$(document).ready(function () {
    
    var $maincontent = $('#content');
	var $menulinks = $('#menu a');

	var pages = {};
	
	function GetSectionTitle(href, id) {
		if (href == "home") {
			return '<h2 id="' + id + '" class="ui header">Rule Engine Docs</h2>';
		} else {
			return '<h2 id="' + id + '" class="ui header">' + $('#menu a[href="' + href + '"]').text() + '</h2>';
		}
	}
	
	function AddContent(href) {
		
		var $menulink = $('#menu a[href="' + href + '"]');
        var content = $('#data #' + href + '.content');
        
        if (content.length && !$menulink.hasClass('hidden')) {
			var title = GetSectionTitle(href, "placemarker_" + href);
            $maincontent.html($maincontent.html() + title + content.html());
        }
        
	}
	
	$menulinks.click(function (event) {
		event.preventDefault();
        var $menulink = $(this);

        var error = function () {
            $menulink.css('color', 'red');
            $maincontent.html($('#unlinked').html());
        };

        var href = $(this).attr('href');

        if (href == "#") {
            error();
            return;
        }
		
		window.location = window.location.href.substr(0, window.location.href.length - window.location.hash.length) + "#" + href;
		location.reload();
	});
	
	// Check that each menu link has content
	$menulinks.each(function () {
		
        var href = $(this).attr('href');

        if (href == undefined || href == "#" || href == "") {
            console.log('Invalid href value for menu link "' + $(this).text() + '"');
        } else {
			if (!($('#data #' + href + '.content').length)) {
				console.log('No content found for menu link "' + $(this).text() + '"');
			}
		}
		
		// Get the content for the whole page
		var pagedetails = GetPageNameAndSection(href);
		if (pagedetails != null) {
			if (!pages.hasOwnProperty(pagedetails.page)) {
				pages[pagedetails.page] = [];
			}
			pages[pagedetails.page].push(pagedetails.section);
		}
		
	});
	
	function InitPage($menulink) {

        var error = function () {
            $menulink.css('color', 'red');
            $maincontent.html($('#unlinked').html());
        };

        var href = $menulink.attr('href');

        if (href == "#") {
            error();
            return;
        }
		
		var pagedetails = GetPageNameAndSection(href);
		if (pagedetails != null) {
			$maincontent.html("");
			pages[pagedetails.page].forEach(function (element) {
				AddContent(pagedetails.page + '_' + element);
			});
		} else if (href === "home") {
			$maincontent.html("");
			AddContent("home", $menulink);
		}
		
		// Do the formatting
		var $codeblocks = $maincontent.find('code.codeblock');
		$codeblocks.each(function () {
			var codeblock = $(this);
			codeblock.html(codeblock.html().trim());
			codeblock.find('class').each(function () {
				$(this).replaceWith('<div class="class">' + $(this).html() + '</div>');
			});
			codeblock.find('string').each(function () {
				$(this).replaceWith('<div class="string">' + $(this).html() + '</div>');
			});
			codeblock.find('keyword').each(function () {
				$(this).replaceWith('<div class="keyword">' + $(this).html() + '</div>');
			});
			codeblock.html(function() {
				return this.innerHTML.replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
			});
		});
		$codeblocks.wrap('<div class="customcode"><div class="ui segment"><pre>');
		
		// Set up hyper linking
		var links = $maincontent.find('a');
		links.each(function() {
			var link = $(this).attr('href');
			if (link !== undefined && link.startsWith('page://')) {
				$(this).click(function () {
					var pagelink = link.substr(7);
					var menulink = $('#menu a[href="' + pagelink + '"]');
					if (!menulink.length) {
						throw "No link found";
						return;
					}
					menulink.click();
				});
			}
		});
		
		// Able to jump to parts in a page
		console.log($("#placemarker_"+window.location.hash.substr(1)).position().top - $('#menu').outerHeight());
		setTimeout(function () {
			$(document).scrollTop($("#placemarker_"+window.location.hash.substr(1)).position().top - $('#menu').outerHeight());
		}, 50);
		
	}
	
	var hashparam = document.URL.split('#')[1];
	if (hashparam === undefined || hashparam === "") {
		InitPage($('#menu #menuhome'));
	} else {
		InitPage($('#menu a[href="' + hashparam + '"]'));
	}

	// Enable tabs
	$('.menu .item').tab();
	
	SyntaxHighlighter.all();
	
});
})(jQuery);